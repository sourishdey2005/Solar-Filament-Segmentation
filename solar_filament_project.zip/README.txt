Solar Filament Segmentation — Project Bundle
=============================================

folders:
  figures/            all EDA plots produced by Cells C through M
  raw_train_samples/  6 raw training images (H-Alpha, 2048x2048, grayscale)
  raw_test_samples/   6 raw test images (same format)
  csv/                summary.csv, all_metrics.csv, submission.csv (if present)

model results (from validation set):
  Best Val Dice:    0.7102 (epoch 29)
  Mean Dice:        0.6965 (threshold 0.50)
  Median Dice:      0.6919
  Pixel IoU:        0.5313
  Test filaments:   745 across 180 test images

reproduce:
  pip install -r requirements.txt
  download MAGFiLO dataset to data/
  download weights/best_v2.pth
  run notebooks/03_inference.ipynb
